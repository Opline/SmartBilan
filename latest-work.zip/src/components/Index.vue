<template>
    <Formulaire class="styleMemoIndex"></Formulaire>
</template>

<script setup>
import Formulaire from "@/components/Formulaire.vue";
</script>
<style>

</style>
