<template>
  <v-app>
    <v-main>
      <Index />
    </v-main>
  </v-app>
</template>

<script setup>
  import Index from '@/components/Index.vue'

</script>

